#include <iostream>
#include "PokemonClass.h"
#include <iostream>
using namespace std;
int main() {

  Pikachu pika;
  Charmander charmander;
  //testing function call
  pika.pokemonInfo();
  charmander.pokemonInfo();
}