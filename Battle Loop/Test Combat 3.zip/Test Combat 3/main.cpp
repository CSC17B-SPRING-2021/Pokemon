/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Thomas 
 *
 * Created on April 9, 2021, 5:47 PM
 */

#include <cstdlib>
#include "PokemonClass.h"
#include "CombatEvent.h"
#include "player.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //playerclass Player;

    int Player[6] = {25, 1, 4, 0, 0, 0};
    int Enemy[2] = {1, 7};
    /*
    PokemonClass NME[2];
    NME[0].SetUp(7);
    NME[1].SetUp(7);
    //Enemy = &NME(0);
    */
    
    CombatEvent * Fight = new CombatEvent;
    Fight->Combat(Enemy, false, Player);
    
    
    
    return 0;
}

