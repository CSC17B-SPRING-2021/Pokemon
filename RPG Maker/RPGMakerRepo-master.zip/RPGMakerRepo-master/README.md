# RPG Maker Code Repository
All of my resources are free for both commercial and noncommercial projects with credit.
You are free to use, modify and redistribute my resources wherever and for whatever you please so long as you credit me (mjshi) as the original author, or as otherwise stated in the plugin's credits section.
