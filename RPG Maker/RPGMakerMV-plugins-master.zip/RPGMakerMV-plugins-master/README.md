# RPGMakerMV-plugins
Plugins for RPG Maker MV: Available for non-commercial and commercial usage

## Heal On Lv Up
Self-explanatory, you can configure the amount of HP and MP healed when any actor level up, a percentage value or fixed amount.

## Show Enemy HP
Show the enemy HP during a battle on the enemy selector menu, like "Slime HP: 100/100".

You can configure if you want to display the enemy list in a single column (default with this plugin) or two colomuns (normal engine). The two columns mode cut strings like "Earthspir. HP: 200/200".

